document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('game-board');
    const ctx = canvas.getContext('2d');
    const scoreDisplay = document.getElementById('score');
    const gameOverDisplay = document.getElementById('game-over');
    const finalScoreDisplay = document.getElementById('final-score');
    const restartBtn = document.getElementById('restart-btn');
    
    const boxSize = 20;
    const boardWidth = canvas.width;
    const boardHeight = canvas.height;
    
    let snake = [];
    let food = {};
    let direction = 'right';
    let nextDirection = 'right';
    let score = 0;
    let gameSpeed = 150;
    let gameInterval;
    let touchStartX = 0;
    let touchStartY = 0;
    
    // Инициализация игры
    function initGame() {
        snake = [
            {x: 5 * boxSize, y: 10 * boxSize},
            {x: 4 * boxSize, y: 10 * boxSize},
            {x: 3 * boxSize, y: 10 * boxSize}
        ];
        
        direction = 'right';
        nextDirection = 'right';
        score = 0;
        scoreDisplay.textContent = `Счет: ${score}`;
        gameOverDisplay.style.display = 'none';
        
        generateFood();
        
        if (gameInterval) clearInterval(gameInterval);
        gameInterval = setInterval(gameLoop, gameSpeed);
    }
    
    // Генерация еды
    function generateFood() {
        const maxX = (boardWidth / boxSize) - 1;
        const maxY = (boardHeight / boxSize) - 1;
        
        food = {
            x: Math.floor(Math.random() * maxX) * boxSize,
            y: Math.floor(Math.random() * maxY) * boxSize
        };
        
        // Проверка, чтобы еда не появилась на змейке
        for (let segment of snake) {
            if (segment.x === food.x && segment.y === food.y) {
                return generateFood();
            }
        }
    }
    
    // Основной игровой цикл
    function gameLoop() {
        moveSnake();
        if (checkCollision()) {
            gameOver();
            return;
        }
        drawGame();
    }
    
    // Движение змейки
    function moveSnake() {
        direction = nextDirection;
        
        const head = {x: snake[0].x, y: snake[0].y};
        
        switch (direction) {
            case 'up':
                head.y -= boxSize;
                break;
            case 'down':
                head.y += boxSize;
                break;
            case 'left':
                head.x -= boxSize;
                break;
            case 'right':
                head.x += boxSize;
                break;
        }
        
        snake.unshift(head);
        
        // Проверка, съела ли змейка еду
        if (head.x === food.x && head.y === food.y) {
            score += 10;
            scoreDisplay.textContent = `Счет: ${score}`;
            
            // Увеличиваем скорость каждые 50 очков
            if (score % 50 === 0 && gameSpeed > 50) {
                gameSpeed -= 10;
                clearInterval(gameInterval);
                gameInterval = setInterval(gameLoop, gameSpeed);
            }
            
            generateFood();
        } else {
            snake.pop();
        }
    }
    
    // Проверка столкновений
    function checkCollision() {
        const head = snake[0];
        
        // Столкновение со стенами
        if (
            head.x < 0 ||
            head.y < 0 ||
            head.x >= boardWidth ||
            head.y >= boardHeight
        ) {
            return true;
        }
        
        // Столкновение с собой
        for (let i = 1; i < snake.length; i++) {
            if (head.x === snake[i].x && head.y === snake[i].y) {
                return true;
            }
        }
        
        return false;
    }
    
    // Отрисовка игры
    function drawGame() {
        // Очистка холста
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, boardWidth, boardHeight);
        
        // Отрисовка змейки
        for (let i = 0; i < snake.length; i++) {
            ctx.fillStyle = i === 0 ? '#4CAF50' : '#8BC34A';
            ctx.fillRect(snake[i].x, snake[i].y, boxSize, boxSize);
            
            ctx.strokeStyle = '#fff';
            ctx.strokeRect(snake[i].x, snake[i].y, boxSize, boxSize);
        }
        
        // Отрисовка еды
        ctx.fillStyle = '#FF5722';
        ctx.beginPath();
        const centerX = food.x + boxSize / 2;
        const centerY = food.y + boxSize / 2;
        const radius = boxSize / 2;
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.fill();
    }
    
    // Конец игры
    function gameOver() {
        clearInterval(gameInterval);
        finalScoreDisplay.textContent = `Счет: ${score}`;
        gameOverDisplay.style.display = 'block';
    }
    
    // Обработка нажатий клавиш
    document.addEventListener('keydown', (e) => {
        switch (e.key) {
            case 'ArrowUp':
                if (direction !== 'down') nextDirection = 'up';
                break;
            case 'ArrowDown':
                if (direction !== 'up') nextDirection = 'down';
                break;
            case 'ArrowLeft':
                if (direction !== 'right') nextDirection = 'left';
                break;
            case 'ArrowRight':
                if (direction !== 'left') nextDirection = 'right';
                break;
        }
    });
    
    // Обработка касаний для мобильных устройств
    canvas.addEventListener('touchstart', (e) => {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
    }, false);
    
    canvas.addEventListener('touchmove', (e) => {
        e.preventDefault();
        if (!touchStartX || !touchStartY) return;
        
        const touchEndX = e.touches[0].clientX;
        const touchEndY = e.touches[0].clientY;
        
        const dx = touchEndX - touchStartX;
        const dy = touchEndY - touchStartY;
        
        if (Math.abs(dx) > Math.abs(dy)) {
            // Горизонтальный свайп
            if (dx > 0 && direction !== 'left') {
                nextDirection = 'right';
            } else if (dx < 0 && direction !== 'right') {
                nextDirection = 'left';
            }
        } else {
            // Вертикальный свайп
            if (dy > 0 && direction !== 'up') {
                nextDirection = 'down';
            } else if (dy < 0 && direction !== 'down') {
                nextDirection = 'up';
            }
        }
        
        touchStartX = 0;
        touchStartY = 0;
    }, false);
    
    // Кнопка перезапуска
    restartBtn.addEventListener('click', initGame);
    
    // Начало игры
    initGame();
});